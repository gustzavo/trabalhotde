﻿namespace trabalho_experiencia_criativa
{
    partial class RGB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numred = new System.Windows.Forms.NumericUpDown();
            this.numgreen = new System.Windows.Forms.NumericUpDown();
            this.numblue = new System.Windows.Forms.NumericUpDown();
            this.lbred = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numblue)).BeginInit();
            this.SuspendLayout();
            // 
            // numred
            // 
            this.numred.Location = new System.Drawing.Point(175, 67);
            this.numred.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numred.Name = "numred";
            this.numred.Size = new System.Drawing.Size(120, 22);
            this.numred.TabIndex = 1;
            this.numred.ValueChanged += new System.EventHandler(this.numblue_ValueChanged);
            // 
            // numgreen
            // 
            this.numgreen.Location = new System.Drawing.Point(175, 95);
            this.numgreen.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numgreen.Name = "numgreen";
            this.numgreen.Size = new System.Drawing.Size(120, 22);
            this.numgreen.TabIndex = 2;
            this.numgreen.ValueChanged += new System.EventHandler(this.numblue_ValueChanged);
            // 
            // numblue
            // 
            this.numblue.Location = new System.Drawing.Point(175, 123);
            this.numblue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numblue.Name = "numblue";
            this.numblue.Size = new System.Drawing.Size(120, 22);
            this.numblue.TabIndex = 3;
            this.numblue.ValueChanged += new System.EventHandler(this.numblue_ValueChanged);
            // 
            // lbred
            // 
            this.lbred.AutoSize = true;
            this.lbred.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbred.ForeColor = System.Drawing.Color.Red;
            this.lbred.Location = new System.Drawing.Point(71, 69);
            this.lbred.Name = "lbred";
            this.lbred.Size = new System.Drawing.Size(48, 20);
            this.lbred.TabIndex = 4;
            this.lbred.Text = "RED";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(71, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "GREEN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(71, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "BLUE";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(301, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(151, 181);
            this.panel1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Principal: NumericUpDown";
            // 
            // RGB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 309);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbred);
            this.Controls.Add(this.numblue);
            this.Controls.Add(this.numgreen);
            this.Controls.Add(this.numred);
            this.Name = "RGB";
            this.Text = "RGB";
            ((System.ComponentModel.ISupportInitialize)(this.numred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numblue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numred;
        private System.Windows.Forms.NumericUpDown numgreen;
        private System.Windows.Forms.NumericUpDown numblue;
        private System.Windows.Forms.Label lbred;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}