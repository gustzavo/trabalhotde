﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_experiencia_criativa
{
    public partial class Calculadora : Form
    {
        public Calculadora()
        {
            InitializeComponent();
            operador.Items.Add('+');
            operador.Items.Add('-');
            operador.Items.Add('/');
            operador.Items.Add('*');
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int conta1 = Convert.ToInt32(tbvalor1.Text);
            int conta2 = Convert.ToInt32(tbvalor2.Text);
            string operando = operador.SelectedItem.ToString();
            int resultado = 0;
            if (operando.Equals("+"))
            {
                resultado = conta1 + conta2;
            }
            else if (operando.Equals("-"))
            {
                resultado = conta1 - conta2;
            }
            else if (operando.Equals("*"))
            {
                resultado = conta1 * conta2;
            }
            else if (operando.Equals("/"))
            {
                resultado = conta1 / conta2;
            }
            MessageBox.Show(resultado.ToString());
        }

        private void Calculadora_Load(object sender, EventArgs e)
        {

        }
    }
}
