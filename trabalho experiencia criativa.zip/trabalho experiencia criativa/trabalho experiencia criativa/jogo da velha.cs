﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_experiencia_criativa
{
    public partial class jogo_da_velha : Form
    {
        int vez = 0;
        int contador = 0;
        public jogo_da_velha()
        {
            InitializeComponent();
        }

        private void desenhar(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (btn.Text == "") 
            {
                if (vez == 0)
                {
                    btn.Text = "O";
                    vez = 1;
                    label1.Text = "Vez da(o): X";
                    
                }
                else
                {
                    btn.Text = "X";
                    vez = 0;
                    label1.Text = "Vez da(o): O";
                }
                contador++;
            }
            venceu();

        }

        void venceu()
        {
            if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X" || button4.Text == "X" && button5.Text == "X" && button6.Text == "X" || button7.Text == "X" && button8.Text == "X" && button9.Text == "X" || button1.Text == "X" && button4.Text == "X" && button7.Text == "X" || button2.Text == "X" && button5.Text == "X" && button8.Text == "X" || button3.Text == "X" && button6.Text == "X" && button9.Text == "X" || button1.Text == "X" && button5.Text == "X" && button9.Text == "X" || button3.Text == "X" && button5.Text == "X" && button9.Text == "X")
            {
                MessageBox.Show("o X ganhou");
                reniciar();
            }
            else if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O" || button4.Text == "O" && button5.Text == "O" && button6.Text == "O" || button7.Text == "O" && button8.Text == "O" && button9.Text == "O" || button1.Text == "O" && button4.Text == "O" && button7.Text == "O" || button2.Text == "O" && button5.Text == "O" && button8.Text == "O" || button3.Text == "O" && button6.Text == "O" && button9.Text == "O" || button1.Text == "O" && button5.Text == "O" && button9.Text == "O" || button3.Text == "O" && button5.Text == "O" && button9.Text == "O")
            {
                MessageBox.Show("o O ganhou");
                reniciar();
            }
            else if (contador == 9) 
            {
                MessageBox.Show("Velha");
                reniciar();

            }
        }

        void reniciar() 
        {
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            vez = 0;
            contador = 0;
            label1.Text = "Vez da(o) O";
        }
    }
}
