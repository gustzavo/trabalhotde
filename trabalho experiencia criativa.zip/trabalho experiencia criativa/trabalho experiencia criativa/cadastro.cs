﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_experiencia_criativa
{
    public partial class cadastro : Form
    {
        public cadastro()
        {
            InitializeComponent();
        }

        private void salvar_Click(object sender, EventArgs e)
        {
            if (lbnome.Text == "") { lbnome.BackColor = Color.Red; }
            else { lbnome.BackColor = Color.White; }
            if (lbsobrenome.Text == "") { lbsobrenome.BackColor = Color.Red; }
            else { lbsobrenome.BackColor = Color.White; }
            if (lbmatricula.Text == "") { lbmatricula.BackColor = Color.Red; }
            else { lbmatricula.BackColor = Color.White; }
            if (lbemail.Text == "") { lbemail.BackColor = Color.Red; }
            else { lbemail.BackColor = Color.White; }
            if (lbsenha.Text == "") { lbsenha.BackColor = Color.Red; }
            else { lbsenha.BackColor = Color.White; }
            if (lbconfirmarsenha.Text == "") { lbconfirmarsenha.BackColor = Color.Red; }
            else { lbconfirmarsenha.BackColor = Color.White; }
            if (lbsenha.Text != lbconfirmarsenha.Text ||     lbsenha.Text == "") 
            {
                MessageBox.Show("As senhas não conferem.");
                lbsenha.Text = "";
                lbconfirmarsenha.Text = "";
            }
            if (lbnome.Text != "" && lbsobrenome.Text != "" && lbemail.Text != "" && lbmatricula.Text != "" && lbsenha.Text != "" && lbconfirmarsenha.Text != "" && lbconfirmarsenha.Text == lbsenha.Text) { MessageBox.Show("DADOS GRAVADOS!!!"); }
        }

        private void lbnome_TextChanged(object sender, EventArgs e)
        {
            lbnome.BackColor = Color.White;
        }

        private void lbsobrenome_TextChanged(object sender, EventArgs e)
        {
            lbsobrenome.BackColor = Color.White;
        }

        private void lbmatricula_TextChanged(object sender, EventArgs e)
        {
            lbmatricula.BackColor = Color.White;
        }

        private void lbemail_TextChanged(object sender, EventArgs e)
        {
            lbemail.BackColor = Color.White;
        }

        private void lbsenha_TextChanged(object sender, EventArgs e)
        {
            lbsenha.BackColor = Color.White;
        }

        private void lbconfirmarsenha_TextChanged(object sender, EventArgs e)
        {
            lbconfirmarsenha.BackColor = Color.White;
        }
    }
}
