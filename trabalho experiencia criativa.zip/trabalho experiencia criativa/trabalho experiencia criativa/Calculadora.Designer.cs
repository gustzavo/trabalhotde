﻿namespace trabalho_experiencia_criativa
{
    partial class Calculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbvalor1 = new System.Windows.Forms.Label();
            this.lbvalor2 = new System.Windows.Forms.Label();
            this.tbvalor1 = new System.Windows.Forms.TextBox();
            this.tbvalor2 = new System.Windows.Forms.TextBox();
            this.operador = new System.Windows.Forms.ComboBox();
            this.lboperasao = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbvalor1
            // 
            this.lbvalor1.AutoSize = true;
            this.lbvalor1.Location = new System.Drawing.Point(22, 58);
            this.lbvalor1.Name = "lbvalor1";
            this.lbvalor1.Size = new System.Drawing.Size(53, 17);
            this.lbvalor1.TabIndex = 0;
            this.lbvalor1.Text = "Valor 1";
            // 
            // lbvalor2
            // 
            this.lbvalor2.AutoSize = true;
            this.lbvalor2.Location = new System.Drawing.Point(187, 58);
            this.lbvalor2.Name = "lbvalor2";
            this.lbvalor2.Size = new System.Drawing.Size(53, 17);
            this.lbvalor2.TabIndex = 1;
            this.lbvalor2.Text = "Valor 2";
            // 
            // tbvalor1
            // 
            this.tbvalor1.Location = new System.Drawing.Point(25, 80);
            this.tbvalor1.Name = "tbvalor1";
            this.tbvalor1.Size = new System.Drawing.Size(84, 22);
            this.tbvalor1.TabIndex = 2;
            // 
            // tbvalor2
            // 
            this.tbvalor2.Location = new System.Drawing.Point(187, 80);
            this.tbvalor2.Name = "tbvalor2";
            this.tbvalor2.Size = new System.Drawing.Size(84, 22);
            this.tbvalor2.TabIndex = 3;
            // 
            // operador
            // 
            this.operador.FormattingEnabled = true;
            this.operador.Location = new System.Drawing.Point(115, 78);
            this.operador.Name = "operador";
            this.operador.Size = new System.Drawing.Size(66, 24);
            this.operador.TabIndex = 4;
            // 
            // lboperasao
            // 
            this.lboperasao.AutoSize = true;
            this.lboperasao.Location = new System.Drawing.Point(112, 56);
            this.lboperasao.Name = "lboperasao";
            this.lboperasao.Size = new System.Drawing.Size(69, 17);
            this.lboperasao.TabIndex = 5;
            this.lboperasao.Text = "Operador";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Location = new System.Drawing.Point(16, 140);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(246, 43);
            this.button1.TabIndex = 6;
            this.button1.Text = "CALCULAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "principal: ComboBox";
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 244);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lboperasao);
            this.Controls.Add(this.operador);
            this.Controls.Add(this.tbvalor2);
            this.Controls.Add(this.tbvalor1);
            this.Controls.Add(this.lbvalor2);
            this.Controls.Add(this.lbvalor1);
            this.Name = "Calculadora";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Calculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbvalor1;
        private System.Windows.Forms.Label lbvalor2;
        private System.Windows.Forms.TextBox tbvalor1;
        private System.Windows.Forms.TextBox tbvalor2;
        private System.Windows.Forms.ComboBox operador;
        private System.Windows.Forms.Label lboperasao;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}