﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_experiencia_criativa
{
    public partial class Listando_Itens : Form
    {
        public Listando_Itens()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            if (tbitem.Text != "")
            {
                itemsit.Items.Add(tbitem.Text);
            }
            tbitem.Text = "";
        }

        private void erraseit_Click(object sender, EventArgs e)
        {
            itemsit.Items.RemoveAt(itemsit.SelectedIndex);   
        }
    }
}
