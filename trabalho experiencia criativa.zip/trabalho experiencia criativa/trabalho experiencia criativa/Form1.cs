﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_experiencia_criativa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void projeto1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cadastro form = new cadastro();
            form.ShowDialog();
        }

        private void projeto2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calculadora form = new Calculadora();
            form.ShowDialog();
        }

        private void projeto3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RGB form = new RGB();
            form.ShowDialog();
        }

        private void projeto4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Listando_Itens form = new Listando_Itens();
            form.ShowDialog();
        }

        private void projeto5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            jogo_da_velha form = new jogo_da_velha();
            form.ShowDialog();
        }

        private void projeto6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.ShowDialog();
        }

        private void projeto10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            painel_label form = new painel_label();
            form.ShowDialog();
        }

        private void projeto8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            crono form = new crono();
            form.ShowDialog();
        }

        private void projeto9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            notification form = new notification();
            form.ShowDialog();
        }

        private void projeto7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calendario form = new Calendario();
            form.ShowDialog();
        }
    }
}
