﻿namespace trabalho_experiencia_criativa
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.projetosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeto10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.projetosToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // projetosToolStripMenuItem
            // 
            this.projetosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.projeto1ToolStripMenuItem,
            this.projeto2ToolStripMenuItem,
            this.projeto3ToolStripMenuItem,
            this.projeto4ToolStripMenuItem,
            this.projeto5ToolStripMenuItem,
            this.projeto6ToolStripMenuItem,
            this.projeto7ToolStripMenuItem,
            this.projeto8ToolStripMenuItem,
            this.projeto9ToolStripMenuItem,
            this.projeto10ToolStripMenuItem});
            this.projetosToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projetosToolStripMenuItem.Name = "projetosToolStripMenuItem";
            this.projetosToolStripMenuItem.Size = new System.Drawing.Size(68, 26);
            this.projetosToolStripMenuItem.Text = "projetos";
            // 
            // projeto1ToolStripMenuItem
            // 
            this.projeto1ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.projeto1ToolStripMenuItem.Name = "projeto1ToolStripMenuItem";
            this.projeto1ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto1ToolStripMenuItem.Text = "projeto 1";
            this.projeto1ToolStripMenuItem.Click += new System.EventHandler(this.projeto1ToolStripMenuItem_Click);
            // 
            // projeto2ToolStripMenuItem
            // 
            this.projeto2ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.projeto2ToolStripMenuItem.Name = "projeto2ToolStripMenuItem";
            this.projeto2ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto2ToolStripMenuItem.Text = "projeto 2";
            this.projeto2ToolStripMenuItem.Click += new System.EventHandler(this.projeto2ToolStripMenuItem_Click);
            // 
            // projeto3ToolStripMenuItem
            // 
            this.projeto3ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto3ToolStripMenuItem.Name = "projeto3ToolStripMenuItem";
            this.projeto3ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto3ToolStripMenuItem.Text = "projeto 3";
            this.projeto3ToolStripMenuItem.Click += new System.EventHandler(this.projeto3ToolStripMenuItem_Click);
            // 
            // projeto4ToolStripMenuItem
            // 
            this.projeto4ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto4ToolStripMenuItem.Name = "projeto4ToolStripMenuItem";
            this.projeto4ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto4ToolStripMenuItem.Text = "projeto 4";
            this.projeto4ToolStripMenuItem.Click += new System.EventHandler(this.projeto4ToolStripMenuItem_Click);
            // 
            // projeto5ToolStripMenuItem
            // 
            this.projeto5ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto5ToolStripMenuItem.Name = "projeto5ToolStripMenuItem";
            this.projeto5ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto5ToolStripMenuItem.Text = "projeto 5";
            this.projeto5ToolStripMenuItem.Click += new System.EventHandler(this.projeto5ToolStripMenuItem_Click);
            // 
            // projeto6ToolStripMenuItem
            // 
            this.projeto6ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto6ToolStripMenuItem.Name = "projeto6ToolStripMenuItem";
            this.projeto6ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto6ToolStripMenuItem.Text = "projeto 6";
            this.projeto6ToolStripMenuItem.Click += new System.EventHandler(this.projeto6ToolStripMenuItem_Click);
            // 
            // projeto7ToolStripMenuItem
            // 
            this.projeto7ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto7ToolStripMenuItem.Name = "projeto7ToolStripMenuItem";
            this.projeto7ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto7ToolStripMenuItem.Text = "projeto 7";
            this.projeto7ToolStripMenuItem.Click += new System.EventHandler(this.projeto7ToolStripMenuItem_Click);
            // 
            // projeto8ToolStripMenuItem
            // 
            this.projeto8ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto8ToolStripMenuItem.Name = "projeto8ToolStripMenuItem";
            this.projeto8ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto8ToolStripMenuItem.Text = "projeto 8";
            this.projeto8ToolStripMenuItem.Click += new System.EventHandler(this.projeto8ToolStripMenuItem_Click);
            // 
            // projeto9ToolStripMenuItem
            // 
            this.projeto9ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto9ToolStripMenuItem.Name = "projeto9ToolStripMenuItem";
            this.projeto9ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto9ToolStripMenuItem.Text = "projeto 9";
            this.projeto9ToolStripMenuItem.Click += new System.EventHandler(this.projeto9ToolStripMenuItem_Click);
            // 
            // projeto10ToolStripMenuItem
            // 
            this.projeto10ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.projeto10ToolStripMenuItem.Name = "projeto10ToolStripMenuItem";
            this.projeto10ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.projeto10ToolStripMenuItem.Text = "projeto 10";
            this.projeto10ToolStripMenuItem.Click += new System.EventHandler(this.projeto10ToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Checked = true;
            this.sairToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sairToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F);
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(43, 24);
            this.sairToolStripMenuItem.Text = "sair";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Trabalho";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem projetosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeto10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

