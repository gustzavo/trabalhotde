﻿namespace trabalho_experiencia_criativa
{
    partial class cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbnome = new System.Windows.Forms.TextBox();
            this.tbnome = new System.Windows.Forms.Label();
            this.salvar = new System.Windows.Forms.Button();
            this.tbsobrenome = new System.Windows.Forms.Label();
            this.tbmatricula = new System.Windows.Forms.Label();
            this.tbconfirmarsenha = new System.Windows.Forms.Label();
            this.tbsenha = new System.Windows.Forms.Label();
            this.tbemail = new System.Windows.Forms.Label();
            this.lbsobrenome = new System.Windows.Forms.TextBox();
            this.lbsenha = new System.Windows.Forms.TextBox();
            this.lbemail = new System.Windows.Forms.TextBox();
            this.lbconfirmarsenha = new System.Windows.Forms.TextBox();
            this.lbmatricula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbnome
            // 
            this.lbnome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbnome.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnome.Location = new System.Drawing.Point(12, 28);
            this.lbnome.Name = "lbnome";
            this.lbnome.Size = new System.Drawing.Size(100, 22);
            this.lbnome.TabIndex = 0;
            this.lbnome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbnome.TextChanged += new System.EventHandler(this.lbnome_TextChanged);
            // 
            // tbnome
            // 
            this.tbnome.AutoSize = true;
            this.tbnome.Location = new System.Drawing.Point(9, 8);
            this.tbnome.Name = "tbnome";
            this.tbnome.Size = new System.Drawing.Size(49, 17);
            this.tbnome.TabIndex = 1;
            this.tbnome.Text = "Nome:";
            // 
            // salvar
            // 
            this.salvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.salvar.Location = new System.Drawing.Point(12, 281);
            this.salvar.Name = "salvar";
            this.salvar.Size = new System.Drawing.Size(100, 23);
            this.salvar.TabIndex = 2;
            this.salvar.Text = "SALVAR!";
            this.salvar.UseVisualStyleBackColor = true;
            this.salvar.Click += new System.EventHandler(this.salvar_Click);
            // 
            // tbsobrenome
            // 
            this.tbsobrenome.AutoSize = true;
            this.tbsobrenome.Location = new System.Drawing.Point(9, 53);
            this.tbsobrenome.Name = "tbsobrenome";
            this.tbsobrenome.Size = new System.Drawing.Size(85, 17);
            this.tbsobrenome.TabIndex = 3;
            this.tbsobrenome.Text = "Sobrenome:";
            // 
            // tbmatricula
            // 
            this.tbmatricula.AutoSize = true;
            this.tbmatricula.Location = new System.Drawing.Point(9, 98);
            this.tbmatricula.Name = "tbmatricula";
            this.tbmatricula.Size = new System.Drawing.Size(69, 17);
            this.tbmatricula.TabIndex = 4;
            this.tbmatricula.Text = "Matricula:";
            // 
            // tbconfirmarsenha
            // 
            this.tbconfirmarsenha.AutoSize = true;
            this.tbconfirmarsenha.Location = new System.Drawing.Point(9, 233);
            this.tbconfirmarsenha.Name = "tbconfirmarsenha";
            this.tbconfirmarsenha.Size = new System.Drawing.Size(116, 17);
            this.tbconfirmarsenha.TabIndex = 5;
            this.tbconfirmarsenha.Text = "Confirmar senha:";
            // 
            // tbsenha
            // 
            this.tbsenha.AutoSize = true;
            this.tbsenha.Location = new System.Drawing.Point(11, 188);
            this.tbsenha.Name = "tbsenha";
            this.tbsenha.Size = new System.Drawing.Size(53, 17);
            this.tbsenha.TabIndex = 6;
            this.tbsenha.Text = "Senha:";
            // 
            // tbemail
            // 
            this.tbemail.AutoSize = true;
            this.tbemail.Location = new System.Drawing.Point(11, 143);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(51, 17);
            this.tbemail.TabIndex = 7;
            this.tbemail.Text = "E-mail:";
            // 
            // lbsobrenome
            // 
            this.lbsobrenome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbsobrenome.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsobrenome.Location = new System.Drawing.Point(12, 73);
            this.lbsobrenome.Name = "lbsobrenome";
            this.lbsobrenome.Size = new System.Drawing.Size(100, 22);
            this.lbsobrenome.TabIndex = 8;
            this.lbsobrenome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbsobrenome.TextChanged += new System.EventHandler(this.lbsobrenome_TextChanged);
            // 
            // lbsenha
            // 
            this.lbsenha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbsenha.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            this.lbsenha.Location = new System.Drawing.Point(12, 208);
            this.lbsenha.Name = "lbsenha";
            this.lbsenha.PasswordChar = '*';
            this.lbsenha.Size = new System.Drawing.Size(100, 22);
            this.lbsenha.TabIndex = 9;
            this.lbsenha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbsenha.TextChanged += new System.EventHandler(this.lbsenha_TextChanged);
            // 
            // lbemail
            // 
            this.lbemail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbemail.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            this.lbemail.Location = new System.Drawing.Point(12, 163);
            this.lbemail.Name = "lbemail";
            this.lbemail.Size = new System.Drawing.Size(100, 22);
            this.lbemail.TabIndex = 10;
            this.lbemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbemail.TextChanged += new System.EventHandler(this.lbemail_TextChanged);
            // 
            // lbconfirmarsenha
            // 
            this.lbconfirmarsenha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbconfirmarsenha.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            this.lbconfirmarsenha.Location = new System.Drawing.Point(12, 253);
            this.lbconfirmarsenha.Name = "lbconfirmarsenha";
            this.lbconfirmarsenha.PasswordChar = '*';
            this.lbconfirmarsenha.Size = new System.Drawing.Size(100, 22);
            this.lbconfirmarsenha.TabIndex = 11;
            this.lbconfirmarsenha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbconfirmarsenha.TextChanged += new System.EventHandler(this.lbconfirmarsenha_TextChanged);
            // 
            // lbmatricula
            // 
            this.lbmatricula.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbmatricula.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            this.lbmatricula.Location = new System.Drawing.Point(12, 118);
            this.lbmatricula.Name = "lbmatricula";
            this.lbmatricula.Size = new System.Drawing.Size(100, 22);
            this.lbmatricula.TabIndex = 12;
            this.lbmatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lbmatricula.TextChanged += new System.EventHandler(this.lbmatricula_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(186, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 13;
            this.label1.Text = "Principal:TextBox";
            // 
            // cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 325);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbmatricula);
            this.Controls.Add(this.lbconfirmarsenha);
            this.Controls.Add(this.lbemail);
            this.Controls.Add(this.lbsenha);
            this.Controls.Add(this.lbsobrenome);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.tbsenha);
            this.Controls.Add(this.tbconfirmarsenha);
            this.Controls.Add(this.tbmatricula);
            this.Controls.Add(this.tbsobrenome);
            this.Controls.Add(this.salvar);
            this.Controls.Add(this.tbnome);
            this.Controls.Add(this.lbnome);
            this.Name = "cadastro";
            this.Text = "cadastro";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lbnome;
        private System.Windows.Forms.Label tbnome;
        private System.Windows.Forms.Button salvar;
        private System.Windows.Forms.Label tbsobrenome;
        private System.Windows.Forms.Label tbmatricula;
        private System.Windows.Forms.Label tbconfirmarsenha;
        private System.Windows.Forms.Label tbsenha;
        private System.Windows.Forms.Label tbemail;
        private System.Windows.Forms.TextBox lbsobrenome;
        private System.Windows.Forms.TextBox lbsenha;
        private System.Windows.Forms.TextBox lbemail;
        private System.Windows.Forms.TextBox lbconfirmarsenha;
        private System.Windows.Forms.TextBox lbmatricula;
        private System.Windows.Forms.Label label1;
    }
}